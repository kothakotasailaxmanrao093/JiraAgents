# unified-webhook

Single Lambda ingestion point for every provider (Slack, GitHub, and any
provider added later), replacing the need for a bespoke Lambda per provider.

See `webhook_handler.py` for the flow and `providers/base.py` for the
`ProviderPlugin` contract new providers implement. Publishes normalised
`CanonicalEvent`s to each tenant's own `unified-events-{env}-{tenant_id}` SQS
queue (the same per-tenant queue nebula provisions for every tenant), consumed
by that tenant's pulsar pod via `ProviderEventSqsConsumer`.

Route: `/webhooks/v2/{provider_slug}` (API Gateway path param).

## Twilio (SMS / WhatsApp / RCS)

One plugin serves all three — Twilio delivers them through the same Messaging
webhook and the channel is read off the address prefix, so the emitted
`event_type` is `sms.received` / `whatsapp.received` / `rcs.received`.

Twilio is the only provider here that posts `application/x-www-form-urlencoded`
rather than JSON; `ProviderPlugin.parse_body` is the hook for that.

Secret keys (common or per-tenant, same resolution as every other provider):

| Key | Purpose |
|---|---|
| `TWILIO_AUTH_TOKEN` | Signature validation. |
| `TWILIO_WEBHOOK_URL` | The **exact** public URL configured in the Twilio console. Twilio signs over the URL, so a mismatch fails validation — this is supplied rather than reconstructed, which is why this plugin needs none of the query-ordering brute force the voice-webhook does. |
| `TWILIO_NUMBER_TENANT_MAP` | `{"+15559876543": {"tenant_id": "...", "tenant_name": "..."}}`, keyed on the bare E.164 so one entry covers SMS, WhatsApp and RCS for that number. A plain `{"+1555...": "tenant-id"}` string value also works. |

In the Twilio console point the number's **A MESSAGE COMES IN** webhook at
`POST https://<webhook-host>/webhooks/v2/twilio`.

Downstream: pulsar refuses to run an agent for a sender with no
`user_provider_mapping` row (`provider='phone'`) — a phone number is reachable by
anyone, unlike a Slack/Teams channel whose membership is the access boundary.
Carrier keywords (STOP/HELP/…) are dropped before dispatch; enable **Advanced
Opt-Out** on the Messaging Service so Twilio sends the mandated replies.

## Confluence (comments on pages)

Confluence Cloud's own webhooks need an installed Connect/Forge app; a **Confluence
Automation rule** needs none. Its **Send web request** action posts to
`POST https://<webhook-host>/webhooks/v2/confluence?tenant_id=<uuid>&tenant=<name>` with the
header `X-Confluence-Webhook-Secret: <CONFLUENCE_WEBHOOK_SECRET>` and a JSON body built from
smart values:

```json
{
  "event": "comment_created",
  "page_id": "{{page.id}}",
  "comment_id": "{{comment.id}}",
  "page_title": "{{page.title}}",
  "space_key": "{{space.key}}",
  "author_id": "{{comment.author.accountId}}",
  "author_name": "{{comment.author.displayName}}"
}
```

Emits `page.commented` (`comment_updated` → `page.comment_updated`; a top-level
`event_type` wins) with flat `confluence_page_id`, `confluence_comment_id`,
`confluence_page_title`, `confluence_space_key`, `confluence_author` in
`structured_payload`. A Connect webhook body (`comment.container`) is read too.

| Key | Purpose |
|---|---|
| `CONFLUENCE_WEBHOOK_SECRET` | The shared secret the rule sends in `X-Confluence-Webhook-Secret`. |

## GitHub: tenant in the URL

GitHub's repo/org webhook settings cannot add headers, so besides `X-Tenant-ID` the tenant
may come from `?tenant_id=<uuid>&tenant=<name>` on the payload URL (the header wins when
both are sent). `structured_payload` also carries flat `github_event`, `github_action`,
`github_repo`, `github_delivery`, `pr_number` (an `issue_comment` has one only when its
issue is a pull request), `pr_merged`, `pr_base`, `github_comment_id` and
`github_comment_kind` (`issue` / `line` / `review`).
