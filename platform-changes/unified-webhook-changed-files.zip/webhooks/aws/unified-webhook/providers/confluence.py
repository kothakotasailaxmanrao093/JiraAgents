"""
Confluence provider plugin — comments on Confluence pages, pushed as they happen.

Source: a Confluence Automation rule ("When: comment added" -> "Send web
request"). Native Confluence Cloud webhooks need an installed Connect/Forge app;
an Automation rule needs none, and — like Jira's — it can attach a custom
header, so verify_signature checks a shared-secret header
(X-Confluence-Webhook-Secret == CONFLUENCE_WEBHOOK_SECRET) rather than an HMAC.

Tenant resolution: the same as Jira — a query param baked into the URL the rule
posts to: /webhooks/v2/confluence?tenant_id=<uuid>&tenant=<name>.

Payload: the rule sends a small JSON body built from its smart values. The
fields read here (every one a string; only page_id and comment_id required):

    {
      "event":       "comment_created",              # or "comment_updated"
      "page_id":     "{{page.id}}",
      "comment_id":  "{{comment.id}}",
      "page_title":  "{{page.title}}",
      "space_key":   "{{space.key}}",
      "author_id":   "{{comment.author.accountId}}",
      "author_name": "{{comment.author.displayName}}"
    }

A Connect-app webhook body (a "comment" object whose "container" is the page) is
read too, so moving to native webhooks later needs no change here. A top-level
"event_type" sets the canonical event_type directly, as for Jira.

structured_payload carries the fields flat and "confluence_"-prefixed
(confluence_page_id, confluence_comment_id, ...): flat names are what reach an
agent's input fields, and the prefix keeps them apart from Jira's own
(issue_key, comment_id).
"""

import hmac
import uuid
from datetime import UTC, datetime

from canonical_event import CanonicalEvent, EventActor
from providers.base import ProviderPlugin, TenantResolutionError

# The rule's "event" (or a Connect webhook's "webhookEvent") -> canonical event_type.
_EVENT_MAP = {
    "comment_created": "page.commented",
    "comment_updated": "page.comment_updated",
    "comment_removed": "page.comment_removed",
}


def _text(value) -> str:
    return "" if value is None else str(value).strip()


class ConfluencePlugin(ProviderPlugin):
    def verify_signature(self, headers: dict[str, str], body: bytes, config: dict) -> bool:
        secret = config.get("webhook_secret")
        if not secret:
            return False
        provided = headers.get("x-confluence-webhook-secret") or headers.get(
            "X-Confluence-Webhook-Secret"
        )
        if not provided:
            return False
        return hmac.compare_digest(provided, secret)

    def handle_challenge(self, headers: dict[str, str], body: dict) -> dict | None:
        return None  # an Automation rule has no handshake step

    def identify_tenant(
        self, headers: dict[str, str], body: dict, query_params: dict, config: dict
    ) -> str:
        tenant_id = query_params.get("tenant_id")
        if not tenant_id:
            raise TenantResolutionError(
                "Missing ?tenant_id= query param on the Confluence webhook URL"
            )
        return tenant_id

    def to_canonical(
        self, headers: dict[str, str], body: dict, tenant_id: str, config: dict
    ) -> CanonicalEvent:
        comment = body.get("comment") if isinstance(body.get("comment"), dict) else {}
        container = comment.get("container") or comment.get("parent") or {}
        raw_event = _text(body.get("event") or body.get("webhookEvent")) or "comment_created"
        event_type = _text(body.get("event_type")) or _EVENT_MAP.get(
            raw_event, f"{raw_event}.received"
        )

        page_id = _text(body.get("page_id") or container.get("id"))
        comment_id = _text(body.get("comment_id") or comment.get("id"))
        page_title = _text(body.get("page_title") or container.get("title"))
        space_key = _text(body.get("space_key") or container.get("spaceKey"))
        author_id = _text(body.get("author_id") or body.get("userAccountId"))
        author_name = _text(body.get("author_name"))

        return CanonicalEvent(
            event_id=str(uuid.uuid4()),
            event_source="confluence",
            event_type=event_type,
            tenant_id=tenant_id,
            received_at=datetime.now(tz=UTC).isoformat(),
            source_workspace_id=space_key or None,
            source_resource_id=page_id or None,
            # A comment is created once: its id is the dedup key.
            provider_event_id=f"{page_id}:{comment_id}:{raw_event}" if comment_id else None,
            actor=EventActor(
                id=author_id or None,
                display_name=author_name or None,
                actor_type="user",
            ),
            structured_payload={
                # Full raw body first, so every field the rule sends stays reachable.
                **body,
                "confluence_event": raw_event,
                "confluence_page_id": page_id,
                "confluence_comment_id": comment_id,
                "confluence_page_title": page_title,
                "confluence_space_key": space_key,
                "confluence_author": author_name or author_id,
            },
            raw_payload=body,
        )
