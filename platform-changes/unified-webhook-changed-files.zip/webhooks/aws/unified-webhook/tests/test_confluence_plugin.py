"""Unit tests for providers/confluence.py."""

import sys
from pathlib import Path

import pytest

_unified_dir = Path(__file__).resolve().parent.parent
if str(_unified_dir) not in sys.path:
    sys.path.insert(0, str(_unified_dir))

from providers.base import TenantResolutionError
from providers.confluence import ConfluencePlugin

# What the Confluence Automation rule's "Send web request" posts.
RULE_BODY = {
    "event": "comment_created",
    "page_id": "16908289",
    "comment_id": "16700001",
    "page_title": "BTS-12 - TDD v1.2",
    "space_key": "BTS",
    "author_id": "acc-1",
    "author_name": "Priya",
}


class TestVerifySignature:
    def test_valid_shared_secret_passes(self):
        headers = {"x-confluence-webhook-secret": "s3cr3t"}
        assert ConfluencePlugin().verify_signature(headers, b"{}", {"webhook_secret": "s3cr3t"})

    def test_wrong_secret_fails(self):
        headers = {"x-confluence-webhook-secret": "wrong"}
        assert not ConfluencePlugin().verify_signature(headers, b"{}", {"webhook_secret": "s3cr3t"})

    def test_missing_configured_secret_fails(self):
        headers = {"x-confluence-webhook-secret": "x"}
        assert not ConfluencePlugin().verify_signature(headers, b"{}", {})

    def test_missing_header_fails(self):
        assert not ConfluencePlugin().verify_signature({}, b"{}", {"webhook_secret": "s3cr3t"})


class TestIdentifyTenant:
    def test_resolves_via_query_param(self):
        assert ConfluencePlugin().identify_tenant({}, {}, {"tenant_id": "t-1"}, {}) == "t-1"

    def test_missing_query_param_raises(self):
        with pytest.raises(TenantResolutionError, match="tenant_id"):
            ConfluencePlugin().identify_tenant({}, {}, {}, {})


class TestToCanonical:
    def test_rule_body_becomes_page_commented_with_flat_fields(self):
        event = ConfluencePlugin().to_canonical({}, RULE_BODY, "t-1", {})
        assert event.event_source == "confluence"
        assert event.event_type == "page.commented"
        assert event.source_workspace_id == "BTS"
        assert event.source_resource_id == "16908289"
        assert event.provider_event_id == "16908289:16700001:comment_created"
        assert event.actor.display_name == "Priya"
        p = event.structured_payload
        assert p["confluence_page_id"] == "16908289"
        assert p["confluence_comment_id"] == "16700001"
        assert p["confluence_page_title"] == "BTS-12 - TDD v1.2"
        assert p["confluence_event"] == "comment_created"
        assert event.raw_payload == RULE_BODY

    def test_ids_are_strings_even_when_the_rule_sends_numbers(self):
        body = {**RULE_BODY, "page_id": 16908289, "comment_id": 16700001}
        p = ConfluencePlugin().to_canonical({}, body, "t-1", {}).structured_payload
        assert p["confluence_page_id"] == "16908289" and p["confluence_comment_id"] == "16700001"

    def test_an_edit_is_its_own_event_type(self):
        body = {**RULE_BODY, "event": "comment_updated"}
        assert ConfluencePlugin().to_canonical({}, body, "t-1", {}).event_type == (
            "page.comment_updated"
        )

    def test_explicit_event_type_wins(self):
        body = {**RULE_BODY, "event_type": "tdd.question"}
        assert ConfluencePlugin().to_canonical({}, body, "t-1", {}).event_type == "tdd.question"

    def test_a_connect_app_webhook_body_is_read_too(self):
        body = {
            "webhookEvent": "comment_created",
            "userAccountId": "acc-2",
            "comment": {
                "id": 555,
                "container": {"id": 777, "title": "BTS-9 - TDD v1.0", "spaceKey": "BTS"},
            },
        }
        p = ConfluencePlugin().to_canonical({}, body, "t-1", {}).structured_payload
        assert (p["confluence_page_id"], p["confluence_comment_id"]) == ("777", "555")
        assert p["confluence_space_key"] == "BTS" and p["confluence_author"] == "acc-2"
